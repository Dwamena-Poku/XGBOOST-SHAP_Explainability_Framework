# pandas>=2.0

# numpy>=1.24

# scikit-learn>=1.3

# imbalanced-learn>=0.11

# xgboost>=2.0

# shap>=0.44

# matplotlib>=3.7

# openpyxl>=3.1

# jupyter>=1.0

# 

